export declare const enum CacheStoragesEnum {
    LOCAL_STORAGE = 0,
    SESSION_STORAGE = 1,
    MEMORY = 2,
}
