import { CacheStorageAbstract } from '../cache-storage-abstract.service';
import { CacheStoragesEnum } from '../../../enums/cache-storages.enum';
import { StorageValueInterface } from '../../../interfaces/storage-value.interface';
/**
 * Service for storing data in local storage
 */
import * as ɵngcc0 from '@angular/core';
export declare class CacheMemoryStorage extends CacheStorageAbstract {
    private _data;
    getItem(key: string): any;
    setItem(key: string, value: StorageValueInterface): boolean;
    removeItem(key: string): void;
    clear(): void;
    type(): CacheStoragesEnum;
    isEnabled(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<CacheMemoryStorage, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDeclaration<CacheMemoryStorage>;
}

//# sourceMappingURL=cache-memory.service.d.ts.map