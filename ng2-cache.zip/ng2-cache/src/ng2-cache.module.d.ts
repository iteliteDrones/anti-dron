import * as ɵngcc0 from '@angular/core';
export declare class Ng2CacheModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<Ng2CacheModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<Ng2CacheModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<Ng2CacheModule>;
}

//# sourceMappingURL=ng2-cache.module.d.ts.map