/**
 * @license ng2-cache
 * MIT license
 */

import { Injectable, NgModule, Optional } from '@angular/core';
import { __extends } from 'tslib';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Abstract cache storage
 * @abstract
 */
var CacheStorageAbstract = (function () {
    function CacheStorageAbstract() {
    }
    return CacheStorageAbstract;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service for storing data in session storage
 */
var CacheSessionStorage = (function (_super) {
    __extends(CacheSessionStorage, _super);
    function CacheSessionStorage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * @param {?} key
     * @return {?}
     */
    CacheSessionStorage.prototype.getItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        var /** @type {?} */ value = sessionStorage.getItem(key);
        return value ? JSON.parse(value) : null;
    };
    /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    CacheSessionStorage.prototype.setItem = /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    function (key, value) {
        try {
            sessionStorage.setItem(key, JSON.stringify(value));
            return true;
        }
        catch (/** @type {?} */ e) {
            return false;
        }
    };
    /**
     * @param {?} key
     * @return {?}
     */
    CacheSessionStorage.prototype.removeItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        sessionStorage.removeItem(key);
    };
    /**
     * @return {?}
     */
    CacheSessionStorage.prototype.clear = /**
     * @return {?}
     */
    function () {
        sessionStorage.clear();
    };
    /**
     * @return {?}
     */
    CacheSessionStorage.prototype.type = /**
     * @return {?}
     */
    function () {
        return 1 /* SESSION_STORAGE */;
    };
    /**
     * @return {?}
     */
    CacheSessionStorage.prototype.isEnabled = /**
     * @return {?}
     */
    function () {
        try {
            sessionStorage.setItem('test', 'test');
            sessionStorage.removeItem('test');
            return true;
        }
        catch (/** @type {?} */ e) {
            return false;
        }
    };
    CacheSessionStorage.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    CacheSessionStorage.ctorParameters = function () { return []; };
    return CacheSessionStorage;
}(CacheStorageAbstract));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service for storing data in local storage
 */
var CacheLocalStorage = (function (_super) {
    __extends(CacheLocalStorage, _super);
    function CacheLocalStorage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * @param {?} key
     * @return {?}
     */
    CacheLocalStorage.prototype.getItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        var /** @type {?} */ value = localStorage.getItem(key);
        return value ? JSON.parse(value) : null;
    };
    /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    CacheLocalStorage.prototype.setItem = /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    function (key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        }
        catch (/** @type {?} */ e) {
            return false;
        }
    };
    /**
     * @param {?} key
     * @return {?}
     */
    CacheLocalStorage.prototype.removeItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        localStorage.removeItem(key);
    };
    /**
     * @return {?}
     */
    CacheLocalStorage.prototype.clear = /**
     * @return {?}
     */
    function () {
        localStorage.clear();
    };
    /**
     * @return {?}
     */
    CacheLocalStorage.prototype.type = /**
     * @return {?}
     */
    function () {
        return 0 /* LOCAL_STORAGE */;
    };
    /**
     * @return {?}
     */
    CacheLocalStorage.prototype.isEnabled = /**
     * @return {?}
     */
    function () {
        try {
            localStorage.setItem('test', 'test');
            localStorage.removeItem('test');
            return true;
        }
        catch (/** @type {?} */ e) {
            return false;
        }
    };
    CacheLocalStorage.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    CacheLocalStorage.ctorParameters = function () { return []; };
    return CacheLocalStorage;
}(CacheStorageAbstract));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service for storing data in local storage
 */
var CacheMemoryStorage = (function (_super) {
    __extends(CacheMemoryStorage, _super);
    function CacheMemoryStorage() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._data = {};
        return _this;
    }
    /**
     * @param {?} key
     * @return {?}
     */
    CacheMemoryStorage.prototype.getItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        return this._data[key] ? this._data[key] : null;
    };
    /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    CacheMemoryStorage.prototype.setItem = /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    function (key, value) {
        this._data[key] = value;
        return true;
    };
    /**
     * @param {?} key
     * @return {?}
     */
    CacheMemoryStorage.prototype.removeItem = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        delete this._data[key];
    };
    /**
     * @return {?}
     */
    CacheMemoryStorage.prototype.clear = /**
     * @return {?}
     */
    function () {
        this._data = [];
    };
    /**
     * @return {?}
     */
    CacheMemoryStorage.prototype.type = /**
     * @return {?}
     */
    function () {
        return 2 /* MEMORY */;
    };
    /**
     * @return {?}
     */
    CacheMemoryStorage.prototype.isEnabled = /**
     * @return {?}
     */
    function () {
        return true;
    };
    CacheMemoryStorage.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    CacheMemoryStorage.ctorParameters = function () { return []; };
    return CacheMemoryStorage;
}(CacheStorageAbstract));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var CACHE_PREFIX = 'CacheService';
var DEFAULT_STORAGE = 1;
var DEFAULT_ENABLED_STORAGE = 2;
var CacheService = (function () {
    function CacheService(_storage) {
        this._storage = _storage;
        /**
         * Default cache options
         */
        this._defaultOptions = {
            expires: Number.MAX_VALUE,
            maxAge: Number.MAX_VALUE
        };
        /**
         * Cache prefix
         */
        this._prefix = CACHE_PREFIX;
        this._validateStorage();
    }
    /**
     * Set data to cache
     * @param {?} key
     * @param {?} value
     * @param {?=} options
     * @return {?}
     */
    CacheService.prototype.set = /**
     * Set data to cache
     * @param {?} key
     * @param {?} value
     * @param {?=} options
     * @return {?}
     */
    function (key, value, options) {
        var /** @type {?} */ storageKey = this._toStorageKey(key);
        options = options ? options : this._defaultOptions;
        if (this._storage.setItem(storageKey, this._toStorageValue(value, options))) {
            if (!this._isSystemKey(key) && options.tag) {
                this._saveTag(options.tag, storageKey);
            }
            return true;
        }
        return false;
    };
    /**
     * Get data from cache
     * @param {?} key
     * @return {?} any
     */
    CacheService.prototype.get = /**
     * Get data from cache
     * @param {?} key
     * @return {?} any
     */
    function (key) {
        var /** @type {?} */ storageValue = this._storage.getItem(this._toStorageKey(key)), /** @type {?} */
        value = null;
        if (storageValue) {
            if (this._validateStorageValue(storageValue)) {
                value = storageValue.value;
            }
            else {
                this.remove(key);
            }
        }
        return value;
    };
    /**
     * Check if value exists
     * @param {?} key
     * @return {?} boolean
     */
    CacheService.prototype.exists = /**
     * Check if value exists
     * @param {?} key
     * @return {?} boolean
     */
    function (key) {
        return !!this.get(key);
    };
    /**
     * Remove item from cache
     * @param {?} key
     * @return {?}
     */
    CacheService.prototype.remove = /**
     * Remove item from cache
     * @param {?} key
     * @return {?}
     */
    function (key) {
        this._storage.removeItem(this._toStorageKey(key));
        this._removeFromTag(this._toStorageKey(key));
    };
    /**
     * Remove all from cache
     * @return {?}
     */
    CacheService.prototype.removeAll = /**
     * Remove all from cache
     * @return {?}
     */
    function () {
        this._storage.clear();
    };
    /**
     * Get all tag data
     * @param {?} tag
     * @return {?} Array
     */
    CacheService.prototype.getTagData = /**
     * Get all tag data
     * @param {?} tag
     * @return {?} Array
     */
    function (tag) {
        var _this = this;
        var /** @type {?} */ tags = this.get(this._tagsStorageKey()) || {}, /** @type {?} */
        result = {};
        if (tags[tag]) {
            tags[tag].forEach(function (key) {
                var /** @type {?} */ data = _this.get(_this._fromStorageKey(key));
                if (data) {
                    result[_this._fromStorageKey(key)] = data;
                }
            });
        }
        return result;
    };
    /**
     * Create a new instance of cache with needed storage
     * @param {?} type
     * returns CacheService
     * @return {?}
     */
    CacheService.prototype.useStorage = /**
     * Create a new instance of cache with needed storage
     * @param {?} type
     * returns CacheService
     * @return {?}
     */
    function (type) {
        var /** @type {?} */ service = new CacheService(this._initStorage(type));
        service.setGlobalPrefix(this._getCachePrefix());
        return service;
    };
    /**
     * Remove all by tag
     * @param {?} tag
     * @return {?}
     */
    CacheService.prototype.removeTag = /**
     * Remove all by tag
     * @param {?} tag
     * @return {?}
     */
    function (tag) {
        var _this = this;
        var /** @type {?} */ tags = this.get(this._tagsStorageKey()) || {};
        if (tags[tag]) {
            tags[tag].forEach(function (key) {
                _this._storage.removeItem(key);
            });
            delete tags[tag];
            this.set(this._tagsStorageKey(), tags);
        }
    };
    /**
     * Set global cache key prefix
     * @param {?} prefix
     * @return {?}
     */
    CacheService.prototype.setGlobalPrefix = /**
     * Set global cache key prefix
     * @param {?} prefix
     * @return {?}
     */
    function (prefix) {
        this._prefix = prefix;
    };
    /**
     * Validate cache storage
     * @return {?}
     */
    CacheService.prototype._validateStorage = /**
     * Validate cache storage
     * @return {?}
     */
    function () {
        if (!this._storage) {
            this._storage = this._initStorage(DEFAULT_STORAGE);
        }
        if (!this._storage.isEnabled()) {
            this._storage = this._initStorage(DEFAULT_ENABLED_STORAGE);
        }
    };
    /**
     * Remove key from tags keys list
     * @param {?} key
     * @return {?}
     */
    CacheService.prototype._removeFromTag = /**
     * Remove key from tags keys list
     * @param {?} key
     * @return {?}
     */
    function (key) {
        var /** @type {?} */ tags = this.get(this._tagsStorageKey()) || {}, /** @type {?} */
        index;
        for (var /** @type {?} */ tag in tags) {
            index = tags[tag].indexOf(key);
            if (index !== -1) {
                tags[tag].splice(index, 1);
                this.set(this._tagsStorageKey(), tags);
                break;
            }
        }
    };
    /**
     * Init storage by type
     * @param {?} type
     * @return {?} CacheStorageAbstract
     */
    CacheService.prototype._initStorage = /**
     * Init storage by type
     * @param {?} type
     * @return {?} CacheStorageAbstract
     */
    function (type) {
        var /** @type {?} */ storage;
        switch (type) {
            case 1 /* SESSION_STORAGE */:
                storage = new CacheSessionStorage();
                break;
            case 0 /* LOCAL_STORAGE */:
                storage = new CacheLocalStorage();
                break;
            default: storage = new CacheMemoryStorage();
        }
        return storage;
    };
    /**
     * @param {?} key
     * @return {?}
     */
    CacheService.prototype._toStorageKey = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        return this._getCachePrefix() + key;
    };
    /**
     * @param {?} key
     * @return {?}
     */
    CacheService.prototype._fromStorageKey = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        return key.replace(this._getCachePrefix(), '');
    };
    /**
     * Prepare value to set to storage
     * @param {?} value
     * @param {?} options
     * returns {value: any, options: CacheOptionsInterface}
     * @return {?}
     */
    CacheService.prototype._toStorageValue = /**
     * Prepare value to set to storage
     * @param {?} value
     * @param {?} options
     * returns {value: any, options: CacheOptionsInterface}
     * @return {?}
     */
    function (value, options) {
        return {
            value: value,
            options: this._toStorageOptions(options)
        };
    };
    /**
     * Prepare options to set to storage
     * @param {?} options
     * @return {?} CacheOptionsInterface
     */
    CacheService.prototype._toStorageOptions = /**
     * Prepare options to set to storage
     * @param {?} options
     * @return {?} CacheOptionsInterface
     */
    function (options) {
        var /** @type {?} */ storageOptions = {};
        storageOptions.expires = options.expires ? options.expires :
            (options.maxAge ? Date.now() + (options.maxAge * 1000) : this._defaultOptions.expires);
        storageOptions.maxAge = options.maxAge ? options.maxAge : this._defaultOptions.maxAge;
        return storageOptions;
    };
    /**
     * Validate storage value
     * @param {?} value
     * @return {?} boolean
     */
    CacheService.prototype._validateStorageValue = /**
     * Validate storage value
     * @param {?} value
     * @return {?} boolean
     */
    function (value) {
        return !!value.options.expires && value.options.expires > Date.now();
    };
    /**
     * check if its system cache key
     * @param {?} key
     * returns boolean
     * @return {?}
     */
    CacheService.prototype._isSystemKey = /**
     * check if its system cache key
     * @param {?} key
     * returns boolean
     * @return {?}
     */
    function (key) {
        return [this._tagsStorageKey()].indexOf(key) !== -1;
    };
    /**
     * Save tag to list of tags
     * @param {?} tag
     * @param {?} key
     * @return {?}
     */
    CacheService.prototype._saveTag = /**
     * Save tag to list of tags
     * @param {?} tag
     * @param {?} key
     * @return {?}
     */
    function (tag, key) {
        var /** @type {?} */ tags = this.get(this._tagsStorageKey()) || {};
        if (!tags[tag]) {
            tags[tag] = [key];
        }
        else {
            tags[tag].push(key);
        }
        this.set(this._tagsStorageKey(), tags);
    };
    /**
     * Get global cache prefix
     * returns {string}
     * private
     * @return {?}
     */
    CacheService.prototype._getCachePrefix = /**
     * Get global cache prefix
     * returns {string}
     * private
     * @return {?}
     */
    function () {
        return this._prefix;
    };
    /**
     * @return {?}
     */
    CacheService.prototype._tagsStorageKey = /**
     * @return {?}
     */
    function () {
        return 'CacheService_tags';
    };
    CacheService.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    CacheService.ctorParameters = function () { return [
        { type: CacheStorageAbstract, decorators: [{ type: Optional },] },
    ]; };
    return CacheService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var Ng2CacheModule = (function () {
    function Ng2CacheModule() {
    }
    Ng2CacheModule.decorators = [
        { type: NgModule, args: [{
                    providers: [CacheService]
                },] },
    ];
    /** @nocollapse */
    Ng2CacheModule.ctorParameters = function () { return []; };
    return Ng2CacheModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Angular library starter
 * Build an Angular library compatible with AoT compilation & Tree shaking like an official package
 * Copyright Roberto Simonetti
 * MIT license
 * https://github.com/robisim74/angular-library-starter
 */
/**
 * Entry point for all public APIs of the package.
 */

// This file only reexports content of the `src` folder. Keep it that way.

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { CacheService, CacheStorageAbstract, CacheLocalStorage, CacheMemoryStorage, CacheSessionStorage, Ng2CacheModule };
//# sourceMappingURL=ng2-cache.js.map
